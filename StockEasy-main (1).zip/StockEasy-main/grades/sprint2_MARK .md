# Sprint 2 Marking Scheme

---

## Planning Meetings (RPM.md, sprintN.md) (max 2 marks)


  Planning Meetings Total Mark: 2


---

## Stand-ups (max 10 marks)


  Stand-ups: 10

---


## User Stories (Tracked in Trello) (max 10 marks) 


  User Stories Total Mark: 10

---
## Tracking on Trello  (max 24 marks) 



Tracking on Trello Total Mark: 24

---
## Sprint Completion (Max 20 marks) 
 
    Your Mark: 20

---

## System Design (max 10 marks)


  System Design: 10 
---

## Documentation (max 1 marks)


  Documentation: 1

---
## Demo (Max 10 marks) 
 

  Your Mark: 10
---

## Workload distribution (Max 10 marks) 
 

  Workload distribution: 10
---



## Total Mark

107 / 107

