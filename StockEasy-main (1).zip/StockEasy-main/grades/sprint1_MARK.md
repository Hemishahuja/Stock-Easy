# Sprint 1 Marking Scheme

---

## Planning Meetings (RPM.md, sprintN.md) (max 5 marks)


  Planning Meetings Total Mark: 5 / 5


---

## System Design (max 10 marks)


  System Design: 10 / 10

---
## User Stories (Tracked in Trello) (max 12 marks) 


  User Stories Total Mark: 12 / 12

---
## Tracking on Trello  (max 4 marks) 


Tracking on Trello Total Mark: 15 / 15

---
## Sprint Completion (Max 10 marks) 
 
    Your Mark: 10 /10

---
## Sprint Video Demo (Max 12 marks) 
 

  Your Mark: 10 / 12

---

** all members should present in the video **

## Total Mark

62 / 64

