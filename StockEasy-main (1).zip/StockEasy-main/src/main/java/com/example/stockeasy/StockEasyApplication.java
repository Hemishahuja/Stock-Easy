package com.example.stockeasy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
// UI runs locally while Spring Boot is running
@SpringBootApplication
public class StockEasyApplication {

    public static void main(String[] args) {
        SpringApplication.run(StockEasyApplication.class, args);
    }
}
