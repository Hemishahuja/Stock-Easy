# Project Title: Stock Easy

#### **Project Overview**

Stock Easy is an innovative stock trading simulator that helps traders and beginners practice and simulate managing a portfolio without involving real financial risk. It provides a virtual environment where users can observe real-time or simulated stock prices, buy and sell shares, and track their overall profits and losses. The goal is to create a simple and interactive system for users to be a part of the global stock market.

#### 

#### **Objectives**

The main objective is to help beginners understand the basics of trading, stock price movement, and portfolio management. The system focuses on usability and clarity rather than financial complexity, encouraging learning through experimentation.

#### **Key Users**

1. **Students(Finance, Economics, and Business:**  who are learning finance trading and want practical exposure to market behaviour.  
2. **Casual learners:** who want to practice investing safely.  
3. **Developers and tech enthusiasts:** who want to experiment with new techniques with financial data.  
4. **Companies and new employees:** companies train their new employees.  
   

**Scenario**

1. A finance student at York University is taking a course in the stock market, and the professor asks them to Learn core trading principles, such as buying/selling, diversification, and portfolio management. And practice market analysis through simulated scenarios  \- all this can be done without engaging in the market with real money, hence minimizing any risk. 

2. A dev at OpenAI is trying to understand how his new GPT model will behave when integrated with the StockMarket, understand the model’s behaviour and improve the trading bot’s application and use case. We can have the option to build custom simulations, etc, to test algorithmic trading models with simulated or live data feeds.

3. An intern at Goldman Sachs is trying to practice how to learn portfolio management concepts. And evaluate the portfolio’s performance with our intuitive analytics dashboards.

4. A financial literacy enthusiast is organizing a workshop\! They can ask participants to use  *Stock Easy* as an interactive tool for their workshop, and also do for their community programs, or financial bootcamps. It can also help newcomers grasp complex financial ideas through hands-on engagement.  
   

**Key Principles**

* **Simplicity over complexity:**  The interface must stay clean, intuitive, and free of overwhelming financial jargon.    
*  **Immediate feedback & transparency:** Users should instantly see how buying/selling affects their portfolio and understand how profit/loss is computed.    
* **Extensibility & configurability:** The system should allow switching between real API data and simulated data, and tweak parameters like volatility or update frequency.    
* **Educational focus:** The goal is learning, not real-world trading; mistakes and experiments are part of the learning journey.    
* **Team collaboration:** Code should follow a full-stack structure for scalability and maintainability.


