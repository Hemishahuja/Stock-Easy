doc/sprint0/team.md
# Team Information

| Full Name       | Section | Student ID | Email                 | Best Way to Contact  | Discord Username |
|-----------------|---------|------------|-----------------------|----------------------|------------------|
| Lama Abelfattah |    B    |  218687582 | lamat21@my.yorku.ca   | 6477719682           | 12stl            |                  
| Divy Parikh     |    A    |  220152427 | divy0511@my.yorku.ca  |divy0511@my.yorku.ca  | pickle_1610      |
| Arushi Bisht    |    A    |  219830744 | arushi09@my.yorku.ca  |4374633391- Whatsapp  | pam_tor          |
| Mark Feng       |    B    |  215527161 | markfeng024@gmail.com |markfeng024@gmail.com | mark110019       |
| Hemish Ahuja    |    A    |  219894450 | Hemishahuja@gmail.com |hemishahuja@gmail.com |  Hemishahuja     |

Discord Chat/Server Invite: [https://discord.gg/Wk8WCqtVUc](https://discord.gg/Wk8WCqtVUc)

