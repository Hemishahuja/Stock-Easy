# Process

**Work Dynamics:** Our team’s primary workplace was the Discord server’s voice channel.  We made an effort to accommodate everyone's schedules to ensure that as many team members as possible could join the meeting. Then we would distribute the work amongst ourselves, and work on it during the meeting and collaborate real time\! We would implement a verbal agenda for each meeting to keep discussions focused and ensure all relevant topics were addressed efficiently. 

| Team Member  | Role(s) |
| :---- | :---- |
| Hemish Ahuja | Scrum master, Developer |
| Lama Tamer | Scrum master, Developer |
| Arushi Bisht | Developer, Database manager |
| Divy Parikh | Developer, UX/Research |
| Mark Feng | Developer, QA/DevEx |

**Decision Making:**   
We truly believe in making effective decisions as a part of a synergic team.   
1\) First, we would start by clearly defining the objectives, gathering relevant information from all our members and making sure everyone understands the goal.   
2\) Then we have a round of conversations to brainstorm ideas. One person would organize those ideas, potentially using visualization tools.   
3\) After organization, we discuss the pros and the cons of each idea, and then we try to aim for consensus.   
4\) Once an async voting (i.e. thumbs up or down emoji) is completed and a consensus is reached, we will assign roles and responsibilities to implement the chosen idea and simultaneously link it into the Trello card.   
If we split, the Majority vote will be followed.   
If we cannot reach a consensus, we will repeat steps 1-3 until we do.

   
**Tools Used:**  
 By integrating tools like shared Google Docs documents, we would ensure each one of our inputs is taken care of. We used our Trello board to streamline our workflow and track progress more effectively. 

**Meetings*:***

Our team set up a meeting approximately twice a week depending on the availability of each team member, we worked together through the material of the project. One meeting was to review progress and one to assign new tasks. We stayed in contact through discord messages throughout the weeks which helped us manage possible issues and answer questions in a timely manner. The hour and half long meeting would be divided as follows: 

1) Standup: everyone goes through a brief overview of the agenda and what do in this meeting (5 mins)  
2) Backlog refinement (10 mins): we do clarification and general discussion.  
3) Sprint Planning (60 mins): We do a capacity check, define the goals nicely look at the stories, double check our plan, evaluate risks  etc.   
4) Review (5 mins): We discuss whats done, get feedback and update the backlog if needed. 

**Prioritizing user stories**:

 We picked what to build by aiming for a basic working version first. That meant starting with the most useful steps for a real user: see a stock’s price, add/remove it from a portfolio, then see total value and profit/loss. We did the things that everything else depends on next (like saving the portfolio) and kept nice-to-have features (CSV import/export, extra stats) for later. To size the work, we used simple point sizes (1, 2, 3, 5, 8\) and voted in Discord with emojis—most stories agreed in one quick round, and if people were far apart we chatted for a couple minutes and re-voted. This kept us focused on high value, built the core pieces in the right order, and reduced surprises by tackling tricky parts early.

 **Next phase:**

From Sprint 0 we learned that clear communication and defined ownership prevent overlap and confusion. Keeping Trello updated gave everyone a real-time picture of progress, and brief but regular meetings improved accountability. For the next stage we will begin building the first working version of StockEasy, keep meetings short and focused, and continue documenting key decisions. These habits will help maintain efficiency and teamwork as development moves forward.