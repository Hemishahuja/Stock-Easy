# Product Backlog: Stock Easy — Release 1

#### **Release 1 Objective**

To create a functional, educational, and user-friendly stock trading simulator that allows users to practice buying/selling, tracking portfolios, and analyzing outcomes in a risk-free environment.

#### **User Stories (R1)**
### 1. Viewing Market Data

- **Persona:** Sofia Rodriguez (The Beginner Learner)
- **User Story:** As Sofia, I want to view a list of stock prices that update in real time or simulation mode so that I can see how different companies’ values change and start understanding market behavior.
- **Goal/Desire:** Learn how stock prices fluctuate.
- **Benefit:** Builds confidence and familiarity with real market patterns without confusion or risk.

### 2. Buying Stocks

- **Persona:** Emma Smith (The Casual Learner)
- **User Story:** As Emma, I want to buy virtual shares of companies I recognize so that I can practice making simple investment choices in a safe environment.
- **Goal/Desire:** Try out basic trading decisions.
- **Benefit:** Provides a hands-on, low-pressure way to understand how purchases affect portfolio value.

### 3. Selling Stocks

- **Persona:** Sofia Rodriguez (The Beginner Learner)
- **User Story:** As Sofia, I want to sell the shares I bought earlier so that I can see how profit or loss is calculated and learn when it might be a good time to sell.
- **Goal/Desire:** Understand how selling impacts results.
- **Benefit:** Reinforces decision-making and helps her connect theory to outcomes.

### 4. Portfolio Overview

- **Persona:** Emma Smith (The Casual Learner)
- **User Story:** As Emma, I want to see my portfolio balance, profits, and owned stocks in one simple dashboard so that I can easily track how my trades are performing over time.
- **Goal/Desire:** Stay aware of portfolio performance.
- **Benefit:** Encourages continuous engagement and self-assessment through visual clarity.

### 5. Transaction History

- **Persona:** James Li (The Curious Developer)
- **User Story:** As James, I want to view my full transaction history, including buy/sell timestamps and prices, so that I can analyze my trading patterns and test different strategies.
- **Goal/Desire:** Track and compare performance for self-evaluation.
- **Benefit:** Enables users to refine strategies and gain insights from past actions.

### 6. Analytics and Insights

- **Persona:** James Li (The Curious Developer)
- **User Story:** As James, I want to see analytics and performance metrics like profit percentage, risk level, and trade frequency so that I can evaluate how well my trading approach performs in various market conditions.
- **Goal/Desire:** Get measurable feedback from simulated trading.
- **Benefit:** Helps him adjust his strategy and improve analytical thinking.

### 7. Starting Virtual Balance

- **Persona:** Sofia Rodriguez (The Beginner Learner)
- **User Story:** As Sofia, I want to start with a set amount of virtual money (e.g., $1,000) so that I can learn to manage a small portfolio and make trading decisions based on limited resources.
- **Goal/Desire:** Learn risk management through practice.
- **Benefit:** Builds a sense of responsibility and introduces budgeting concepts.

### 8. Switching Between Real and Simulated Data

- **Persona:** James Li (The Curious Developer)
- **User Story:** As James, I want to switch between live API data and simulated data so that I can compare how real-world market trends differ from controlled simulations.
- **Goal/Desire:** Test models under different data environments.
- **Benefit:** Enhances experimental learning and supports development testing.

### 9. Educational Feedback and Tutorials

- **Persona:** Sofia Rodriguez (The Beginner Learner)
- **User Story:** As Sofia, I want to receive short explanations or tips after I buy or sell a stock so that I can understand what happened and learn how to improve next time.
- **Goal/Desire:** Receive guidance while learning.
- **Benefit:** Reinforces learning through immediate, meaningful feedback.

### 10. Simple, Clean Interface

- **Persona:** Emma Smith (The Casual Learner)
- **User Story:** As Emma, I want the interface to be clean, simple, and free of financial jargon so that I can focus on learning how trading works without feeling overwhelmed.
- **Goal/Desire:** Have a stress-free learning environment.
- **Benefit:** Improves usability and encourages regular engagement.

### 11. Search and Symbol Detail

- **Persona:** Emma Smith (The Casual Learner)
- **User Story:** As Emma, I want to search by company name or symbol and open a stock page with price and a simple trade ticket so that I can quickly act on a stock I recognize.
- **Goal/Desire:** Find and act on a stock quickly.
- **Benefit:** Reduces friction for new traders.

### 12. Trade Form Validation

- **Persona:** Sofia Rodriguez (The Beginner Learner)
- **User Story:** As Sofia, I want clear errors when I enter an invalid quantity or don’t have enough cash so that I don’t get confused.
- **Goal/Desire:** Prevent simple mistakes.
- **Benefit:** Builds a sense of reliability.

### 13. Cash vs Buying Power Display

- **Persona:** Emma Smith (The Casual Learner)
- **User Story:** As Emma, I want to see cash and buying power with short tooltips so that I know what I can spend right now.
- **Goal/Desire:** Immediate clarity on funds.
- **Benefit:** Fewer surprises when trading.

### 14. Holdings with Statistics

- **Persona:** Sofia Rodriguez (The Beginner Learner)
- **User Story:** As Sofia, I want each holding to show shares, average cost, current price, and market value so that I can see what’s up or down.
- **Goal/Desire:** Understand performance per holding.
- **Benefit:** Visual learning of outcomes.

### 15. Trade History: Filter and Reorder

- **Persona:** James Li (The Curious Developer)
- **User Story:** As James, I want to quickly filter and sort my trade history by date, stock, and whether it was a buy or a sell so I can spot patterns.
- **Goal/Desire:** Find patterns faster.
- **Benefit:** Easier to review what worked.

### 16. Quick Trade from Holdings

- **Persona:** Emma Smith (The Casual Learner)
- **User Story:** As Emma, I want to start a buy or sell directly from my holdings list so I don’t have to leave the portfolio page.
- **Goal/Desire:** Reduce steps to trade.
- **Benefit:** Faster, more intuitive flow.

### 17. Star Trades for Review

- **Persona:** Sofia Rodriguez (The Beginner Learner)
- **User Story:** As Sofia, I want to star certain trades so I can find them later to learn from them.
- **Goal/Desire:** Mark moments worth reviewing.
- **Benefit:** Focused reflection.

### 18. First-Time Guided Tour

- **Persona:** Sofia Rodriguez (The Beginner Learner)
- **User Story:** As Sofia, I want a quick 3–5 step tour the first time I open the app so I understand the main screens.
- **Goal/Desire:** Get oriented quickly.
- **Benefit:** Lower learning curve.

### 19. Basics Page

- **Persona:** Emma Smith (The Casual Learner)
- **User Story:** As Emma, I want a single “Learn the Basics” page with plain-language definitions of key concepts so I can understand important ideas quickly.
- **Goal/Desire:** Easy way to learn the basics.
- **Benefit:** Confidence without jargon.

### 20. Reset Sandbox

- **Persona:** Sofia Rodriguez (The Beginner Learner)
- **User Story:** As Sofia, I want to reset my account to the starting balance and clear positions so that I can practice from scratch.
- **Goal/Desire:** Fresh practice runs.
- **Benefit:** Encourages repeated learning cycles.