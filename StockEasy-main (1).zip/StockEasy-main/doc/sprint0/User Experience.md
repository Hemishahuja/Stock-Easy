# User Experience (UX) – Stock Easy

### 1. Logical Relation to Scenarios

The user experience of Stock Easy is directly aligned with the main user scenarios outlined in summary.md and the defined personas:

- Sofia Rodriguez (Beginner Learner) – The interface supports Sofia’s goal of learning in a simple and guided environment. When she logs in, she’s greeted with a clean dashboard showing her virtual balance, quick “Buy” and “Sell” buttons, and short tutorial prompts explaining each feature. This aligns with her scenario of gaining confidence through trial and error without complexity.  

- Emma Smith (Casual Learner) – The platform offers an intuitive and visually clear design, making it easy for Emma to trade stocks during short breaks. The layout uses minimal text, icon-based navigation, and color-coded profit/loss indicators to provide instant feedback, matching her need for a relaxed, low-effort learning experience.  

- James Li (Curious Developer) – The UX includes analytics and a transaction history section, letting James review performance metrics and test trading strategies. His scenario focuses on exploring strategies and evaluating data; therefore, Stock Easy provides sortable tables, graphs, and a toggle to switch between real-time API data and simulated data for experimentation.  

Relation to Scenarios: Each interface element directly supports the personas’ learning paths and mirrors their real-world motivations — learning, experimenting, and testing.

---

### 2. Graphic Representation of the Interface

The visual design (as represented in the UX mockups or wireframes) is clear, consistent, and focused on usability:

#### Home / Dashboard Screen

- Top Bar: Shows Stock Easy logo, virtual balance (e.g., “$1,000”), and profile icon.  

- Main Panel: Displays real-time stock list with company name, ticker symbol, price, and % change (green/red highlighting for rise/fall).  

- Action Buttons: Prominent “Buy” and “Sell” buttons appear beside each stock, ensuring one-click trading for beginners.  

- Quick Tutorial Banner: A small pop-up tip (e.g., “Tip: Buy when you expect the price to rise!”) for guidance after each trade.  


#### Portfolio Page

- Pie Chart / Graph: Visual breakdown of owned stocks and their percentage value in the portfolio.  

- Performance Summary: Shows total profit/loss and growth trend over time.  

- Transaction History Table: Columns for Date, Action (Buy/Sell), Quantity, Price, and Result.  


#### Analytics Page (for Advanced Users like James)

- Toggle Button: Switch between Simulated Data and Real Data.  

- Charts: Line graph tracking portfolio performance, bar chart for sector allocation.  

- Insight Cards: Quick metrics such as “Best Performing Stock,” “Average Holding Period,” etc.  


#### Color and Design Principles

- Primary Colors: Blue and white for simplicity and trust.  

- Feedback Cues: Green for profit, red for loss, grey for neutral.  

- Typography: Clean sans-serif fonts to enhance readability.  

- Consistency: Every page uses a top navigation bar and minimal clutter to ensure a stress-free experience.  


Graphic Representation: Each interface section visually supports intended functions (market viewing, trading, tracking, and learning) and aligns perfectly with user expectations for clarity and feedback.