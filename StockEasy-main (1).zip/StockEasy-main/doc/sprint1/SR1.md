
# SR1 — Sprint 1 Retrospective (StockEasy)

**Date/Time:** 2025-11-03

**Sprint length:** 2 weeks

**Note-taker:** Mark

---

## Participants
- Hemish Ahuja
- Lama Abdelfattah
- Arushi Bisht
- Divy Parikh
- Mark Feng

_Attendance confirmed for all names above._

---

## Unfinished work: User stories as detailed in PB.md

---

## Keep (practices to continue)

- Small, task-scoped branches and PRs tied to Trello cards.
- Pairing on tricky service logic (e.g., transactions).
- Using interfaces between layers (controllers → services → repositories) as shown in our architecture.

---

## Try (new practices to adopt)

- **Demo-first mindset:** build the minimal slice that is demo-able end-to-end.
- **UX review pass** before merging any page (content layout, empty states).

---

## Stop (practices to drop)

- Starting work on a story without acceptance criteria.
- Large, multi-feature PRs that are hard to review.
- Merging without at least one peer review.
- Untracked scope creep during the sprint.

---

## Best/Worst experiences (Sprint 1)
- **Best:** Seeing the request flow end-to-end (Controller → Service → Repository → DB) and rendering the dashboard for the first time.
- **Worst:** Environment setup differences and merge conflicts near the deadline; occasional confusion over where trading endpoints should live.
