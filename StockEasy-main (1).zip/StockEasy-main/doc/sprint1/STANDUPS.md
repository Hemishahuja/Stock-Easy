### **October 29, 2025 – Sprint 1 Standup 1**

1. **What did you work on since the last standup?**

   * Discussed approach for Sprint 1

   * Divided the backlog items among team members

2. **What do you commit to next?**

   * Read the Software Architecture document and decide what the overall structure of the project will look like.

3. **When do you think you'll be done?**

   * November 2

4. **Do you have any blockers?**

   * Need confirmation on whether the planned architecture is feasible

### **November 2, 2025 – Sprint 1 Standup 2**

1. **What did you work on since the last standup?**

   * Created the Trello board and added user stories

   * Broke down 3 backlog items into subtasks

2. **What do you commit to next?**

   * Continue breaking down remaining user stories

   * Add acceptance criteria to each story

3. **When do you think you'll be done?**

   * End of the day of November 2

4. **Do you have any blockers?**

   * Need clarity on the priority order of the remaining backlog items

   

### **November 3, 2025 – Sprint 1 Standup 3**

1. **What did you work on since the last standup?**

   * Finalized Sprint 1 work and recorded the video demo

2. **What do you commit to next?**

   * Start planning Sprint 2 tasks (main focus: API infrastructure implementation and other features) 

3. **When do you think you'll be done?**

   * Midnight

4. **Do you have any blockers?**

   * Finding a free and good API provider to use. 

Prepared by: Arushi Bisht  
Approved by: StockEasy team    
Date: 2025-11-03  
