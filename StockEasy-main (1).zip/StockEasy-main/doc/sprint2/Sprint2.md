# Sprint 2 Planning — StockEasy

**Date/Time:** 2025-11-03  
**Sprint length:** 2 weeks  
**Note-taker:** Arushi

---

## Participants
- Hemish Ahuja  
- Lama Abdelfattah  
- Arushi Bisht  
- Divy Parikh  
- Mark Feng  

_All members participated in planning._

---

## Sprint Goal
The goal of Sprint 2 is to complete at least **three core user stories** and deliver meaningful, user-facing functionality.  
This sprint focuses on:

- Building the **Stocks Marketplace Page**  
- Implementing the **Watchlist Feature**  
- Creating the **Help Page** that provides short tips before/after buy/sell actions  

Additionally, we aim to **merge the stock listing page and the market overview page** into a unified, real-time stock market page with live updates, search, filters, and market data refresh capabilities.

This unified page will give users a single, comprehensive interface to browse stocks, monitor real-time prices, and understand market conditions without navigating to separate pages.

---

## Spikes (Research Tasks)
The team identified the following research spikes for this sprint:

- Investigating **API token limits**, especially for free providers  
- Understanding how to implement efficient and scalable **watchlist logic**  
- Exploring **alternative free stock data providers** due to token restrictions  
- Testing **free-tier API options** for live market data and refresh endpoints  

_All spikes were discussed and assigned at the planning meeting._

---

## Team Capacity

- Hemish — ~8–12 hours  
- Lama — ~8–12 hours  
- Arushi — ~8–12 hours  
- Divy — ~8–12 hours  
- Mark — ~8–12 hours  

_All members confirmed they can contribute at a similar level as last sprint._

---

## User Stories Selected for Sprint 2
1. **Stocks Marketplace Page**  
2. **Watchlist Feature**  
3. **Help Page (Tips after Buy/Sell Transactions)**  
4. **Merge Stock Listing Page + Market Overview into Single Unified Page**

_All user stories were agreed upon and committed to for Sprint 2._

---

## Task Breakdown

### **1. Stocks Marketplace Page**
- Fetch stock data (backend)  
- Display stock list (frontend UI)  
- Implement infrastructure for search and filtering features  
- Connect stock list to existing API  
- Add refresh button for live data
- Add autorefresh

---

### **2. Watchlist Feature**
- Create add/remove endpoint for stocks  
- Watchlist UI page  
- Database linking between users and watched stocks  
- Integrate watchlist buttons on stock cards  
- Display user-specific watchlist items  
- Testing backend + frontend workflows  

---

### **3. Help Page (Tips After Buy/Sell)**
- Write help-tip content for beginners and outcome sugggestions.
- Create Help Page UI  
- Connect page to buy/sell workflow if needed  

## Youtube Video link

https://youtu.be/-nQ7u6bkyI0

---

## Decisions Made During Planning
- Team will strictly follow **one branch per task**  
- Trello will be updated **daily** to track progress  
- Spikes will be completed early in the sprint  
- The unified market page is considered a priority item  
