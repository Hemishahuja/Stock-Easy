# SR2 — Sprint 2 Retrospective (StockEasy)

**Date/Time:** 2025-11-17  
**Sprint length:** 2 weeks  
**Note-taker:** Arushi

---

## Participants
- Hemish Ahuja
- Lama Abdelfattah
- Arushi Bisht
- Divy Parikh
- Mark Feng

_Attendance confirmed for all names above._

---

## Unfinished work
- Some development tasks were started later than planned due to busy team schedules.  
- Delays occurred because of difficulties obtaining and working around API tokens, since many free APIs imposed token limits.  
- A few stories required additional work to fully meet sprint goals, as we aimed to implement them as thoroughly as possible.

---

## Keep (practices to continue)
- Clear and consistent communication among team members.  
- Strong collaboration and willingness to support one another.  
- Effective assignment and understanding of responsibilities.  
- Pairing on complex or unfamiliar material (such as working with external APIs).

---

## Try (new practices to adopt)
- Updating Trello daily to keep task progress accurately reflected.  
- Identifying and addressing potential problems as early as possible to avoid blocking progress later on.
- Debugging as an entire group when running into errors.

---

## Stop (practices to drop)
- Switching between multiple tasks at once; instead, focus on completing one task before starting another.  
- Allowing tasks to progress without proper Trello updates.  
- Combining multiple tasks into a single branch.  

---

## Best/Worst experiences (Sprint 2)
- **Best:** Strong communication and steady collaboration throughout the sprint.  
- **Worst:** Busy schedules caused a slow start to coding, leading to time pressure toward the end of the sprint.
