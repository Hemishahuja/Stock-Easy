 Sprint 2 Retrospective (SR2.md)  
Team: StockEasy    
Date: 2025-10-30    
Location/Platform: Discord  

Attendees: All team members

 What went well  
\- H2 \+ JPA with \`TradeRepository\` stabilized persistence.    
\- \`PriceService\` abstraction simplified portfolio math and tests.

 What didn’t go well  
\- UI hookup for positions/history happened late in the sprint.    
\- Burndown and schedule were updated near the end (need mid-sprint updates).

 Continue / Start / Stop.    
\- Start: enforce mid-sprint burndown/schedule updates    
\- Stop: long-lived branches without review.

 Incomplete / deferred → moved to Sprint 3  
\- Real API adapter for price data (behind feature flag).    
\- Dashboard snapshot card (totals at a glance).    
\- History filters & sort.

 Action items  
\- Add validation (qty\>0, price\>0, cannot oversell) and clear error messages.    
\- Prepare a short demo script   
